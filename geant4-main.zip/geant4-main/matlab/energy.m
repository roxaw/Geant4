%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


gamma_file_path = 'data/gamma10000.txt'; %Specify the path to the gamma particle data file
read_kinetic_energies(gamma_file_path);%Read kinetic energies from the file

%Calculate mean and standard deviation
% mean_energy = mean(gamma_energies);
% std_dev_energy = std(gamma_energies);


%a function to read and process kinetic energy data from a file. This
%function get the path of the file and give an array of kinetic energies
function read_kinetic_energies(file_path)

    kinetic_energies_step0 = [];% Initialize an array to store kinetic energies
    kinetic_energies_step1 = [];
    fid = fopen(file_path, 'r');%Open the file for reading
    if fid == -1
        error('File cannot be opened');%If the file cannot be opened (fid is -1), display an error message
    end

    %Reading the file line by line
    while ~feof(fid)
        line = fgetl(fid);%Read a single line from the file
        line_sep = strsplit(line);%Split the line into separate elements
        if length(line_sep) > 5 && ~contains(line, 'Step#') && ~startsWith(line_sep{1}, "*")%Check if the line has more than 5 elements, and does not start with 'Step' or '*', indicating it contains kinetic energy data.
            energy_value = line_sep{5};%Extract the kinetic energy value (the 5th element in the line)
            try
                %Append the value to the array if it is less than 0.5                
                % if str2double(energy_value) < 0.5 %this threshold is set because a considerable amount of data that we have is out of range and we want to focus on the values less than 0.5
                    if line_sep{1} == '0' 
                        kinetic_energies_step0(end + 1) = str2double(energy_value);
                    elseif line_sep{1} == '1'
                        kinetic_energies_step1(end + 1) = str2double(energy_value);
                    end
                % end
            catch e
                fprintf('An error occurred: %s\n', e.message);%If an error occurs during conversion, print an error message
            end
        end
    end

    %Close the file
    fclose(fid);
    writematrix(kinetic_energies_step0, 'data/kinetic_energies_step0.csv');
    writematrix(kinetic_energies_step1, 'data/kinetic_energies_step1.csv');
end
