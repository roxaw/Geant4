%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Define the input file path
inputFilePath = 'data/gamma10000.txt';
% Open the input file for reading
fid = fopen(inputFilePath, 'r');
% Check if the file opened successfully
if fid == -1
    error('File cannot be opened');
end

% Define output file paths for step 0 and step 1
outputFilePathStep0 = 'data/output_positions10000_step0.csv';
outputFilePathStep1 = 'data/output_positions10000_step1.csv';

% Open output files for writing
fid_out_step0 = fopen(outputFilePathStep0, 'w');
fid_out_step1 = fopen(outputFilePathStep1, 'w');
% Check if the output files opened successfully
if fid_out_step0 == -1 || fid_out_step1 == -1
    error('One or more output files cannot be opened');
end

% Read the input file line by line
while ~feof(fid)
    line = fgets(fid);

    % Check if the line contains position information for step 0 or step 1
    if contains(line, '0    ') || contains(line, '1    ')
        % Split the line into components and extract X, Y, and Z values
        splitLine = strsplit(strtrim(line));
        x = splitLine{2};
        y = splitLine{3};
        z = splitLine{4};

        % Write the position information to the respective output file
        if contains(line, '0    ')
            fprintf(fid_out_step0, '%s,%s,%s\n', x, y, z);
        elseif contains(line, '1    ')
            fprintf(fid_out_step1, '%s,%s,%s\n', x, y, z);
        end
    end
end

% Close the input and output files
fclose(fid);
fclose(fid_out_step0);
fclose(fid_out_step1);

% Display a message confirming completion
disp('Position information for Step 0 and Step 1 has been written to separate output files');
