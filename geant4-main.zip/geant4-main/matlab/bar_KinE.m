%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%ref: https:%www.mathworks.com/help/matlab/ref/matlab.graphics.chart.primitive.histogram.html using this source to get a better sense of plotting a histrogram in MATLAB
threshold = 0.5; %to change the plot threshold

dataStep0 = readmatrix('data/kinetic_energies_step0.csv');%Read data from the CSV file into a matrix

mean_energy = mean(dataStep0);
std_dev_energy = std(dataStep0);
fprintf('Mean Energy of Step0: %f MeV\n', mean_energy);%printing the mean energy value
fprintf('Standard Deviation of Energy of Step0: %f MeV\n', std_dev_energy);%printing the standard deviation of the energy



figure;%create a new figure window for plotting
subplot(2, 1, 1); % To divides the figure window into 2 rows and 1 column and selects the 1st subplot

filtered_data = dataStep0(dataStep0 <= threshold);%here is setting a threshold. The threshold is set to 1 MeV so that it is easier to see the detail. An array of logical values are created corresponding to whether each element in 'dataStep0' satisfies the condition. These filtered values are stored in 'filteredData'



mean_energy_filtered = mean(filtered_data);

histogram(filtered_data, 200);%The histogram function takes 'filteredData' as input and displays it as a histogram. The histogram has 200 bins that provides a detailed distribution of the values

title('KinE Values for Step 0');%setting a title for the plot
xlabel('KinE (MeV)');%labeling the X-axis as "KinE (MeV)"
ylabel('Frequency');%labeling the Y-axis as "Frequency"

% hold on;%keeping the current plot active for adding more features
% xline(mean_energy, 'r--', 'LineWidth', 1);%adding a vertical line that shows the mean energy. The line is red, dashed, and has a line width of 1
hold on;
xline(mean_energy_filtered, 'r--', 'LineWidth', 1);%adding a vertical line that shows the mean energy. The line is red, dashed, and has a line width of 1

% Create the second subplot for Step 1 data
dataStep1 = readmatrix('data/kinetic_energies_step1.csv');%Read data from the CSV file into a matrix
subplot(2, 1, 2); % Select the 2nd subplot
filtered_data_step1 = dataStep1(dataStep1 <= threshold); % Apply the threshold to Step 1 data
histogram(filtered_data_step1, 200); % Plot histogram for filtered Step 1 data
title('KinE Values for Step 1'); % Set title for the second subplot
xlabel('KinE (MeV)'); % Label the X-axis
ylabel('Frequency'); % Label the Y-axis

mean_energy = mean(dataStep1);
std_dev_energy = std(dataStep1);
fprintf('Mean Energy of Step1: %f MeV\n', mean_energy);%printing the mean energy value
fprintf('Standard Deviation of Energy of Step1: %f MeV\n', std_dev_energy);%printing the standard deviation of the energy

mean_energy_filtered = mean(filtered_data_step1);


% hold on;%keeping the current plot active for adding more features
% xline(mean_energy, 'r--', 'LineWidth', 1);%adding a vertical line that shows the mean energy. The line is red, dashed, and has a line width of 1
hold on;
xline(mean_energy_filtered, 'r--', 'LineWidth', 1);%adding a vertical line that shows the mean energy. The line is red, dashed, and has a line width of 1
