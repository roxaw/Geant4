%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%This MATLAB script is getting data from 'result10000.txt' file which
%is the output of a Geant4 program, and seperate the information of gamma
%particles then writes it into 'gamma10000.txt' file.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


outputFilePath = 'data/gamma10000.txt';%we want to write the information in this txt file
file_path = 'data/result10000.txt';%we are using 'result10000.txt' file and parse it to divide the information of gamma
gamma_info = parse_gamma_tracks(file_path);%Call the function 'parse_gamma_tracks' to process the 'result10000.txt' file
write_string_to_file(outputFilePath, gamma_info);%write the processed gamma track data to 'gamma10000.txt

function gamma_info = parse_gamma_tracks(outputFilePath)
    fid = fopen(outputFilePath, 'r');%Open the file for reading
    if fid == -1
        error('File cannot be opened');%if the file cannot be opened print an error message
    end

    gamma_info = {};%Initialize an empty cell array to store the processed gamma information
    is_gamma = false; %Flag to track if current section belongs to a gamma particle

    %Read the file line by line
    while ~feof(fid)
        line = fgetl(fid); % Read a line

        %Check for the start or end of a G4Track information section for gamma particles
        if contains(line, 'Track (trackID') && is_gamma
            is_gamma = false;%Reset the flag to indicate the end of the gamma section
            gamma_info{end+1} = '\n@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n';%this line is a separator line to the 'gamma_info' array
        end

        %Check if the current line indicates the start of a gamma particle section
        if contains(line, 'Particle = gamma')
            is_gamma = true;
        end

        %If in gamma section, add the line to the gamma_info list
        if is_gamma
            gamma_info{end+1} = strtrim(line);%Trim space and add the line to the 'gamma_info' array
        end
    end

    fclose(fid);%Close the file
end

function write_string_to_file(file_path, data)
    
    fid = fopen(file_path, 'w');%Open the file for writing
    if fid == -1
        error('File cannot be opened for writing');%error message if the file cannot be opened
    end

    %Write each item on a new line
    for i = 1:length(data)
        fprintf(fid, '%s\n', data{i});
    end

    fclose(fid);%Close the file
end

