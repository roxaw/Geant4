% Read data from the first file (Step 0)
dataStep0 = readmatrix('data/output_positions10000_step0.csv');

% Extract X, Y, Z coordinates for Step 0
X0 = dataStep0(:, 1);
Y0 = dataStep0(:, 2);
Z0 = dataStep0(:, 3);

% Read data from the second file (Step 1)
dataStep1 = readmatrix('data/output_positions10000_step1.csv');

% Extract X, Y, Z coordinates for Step 1
X1 = dataStep1(:, 1);
Y1 = dataStep1(:, 2);
Z1 = dataStep1(:, 3);

% Create a new figure window for plotting
figure;

% Create the first subplot for Step 0 data
subplot(1, 2, 1); % This divides the figure window into 1 row and 2 columns and selects the 1st subplot
plot3(X0, Y0, Z0, 'o'); % Plot 3D data for Step 0
grid on; % Turn on the grid
xlabel('X Position (mm)');
ylabel('Y Position (mm)');
zlabel('Z Position (mm)');
title('3D Plot of Position Data - Step 0');

% Create the second subplot for Step 1 data
subplot(1, 2, 2); % Select the 2nd subplot
plot3(X1, Y1, Z1, 'o'); % Plot 3D data for Step 1
grid on; % Turn on the grid
xlabel('X Position (mm)');
ylabel('Y Position (mm)');
zlabel('Z Position (mm)');
title('3D Plot of Position Data - Step 1');
